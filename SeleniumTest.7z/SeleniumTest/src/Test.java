import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test {

	public static void main(String[] args) {
		try {
			Random rand = new Random();
			File file = new File(".\\login.txt");
			Scanner sc = new Scanner(file);
			ArrayList<String> login = new ArrayList<String>();
			while (sc.hasNextLine()) {
				login.add(sc.nextLine());
			}
			String username = null;
			String password = null;
			int random=rand.nextInt(25);

			for(String str: login) {
				if(str.split(":")[0].equals("username")) {
					username= str.split(":")[1];
				}
				if(str.split(":")[0].equals("password")) {
					password= str.split(":")[1];
				}
			}
			
			if(username == null || password == null ) throw new Exception("bir hata meydana geldi");
			
			System.setProperty("webdriver.chrome.driver", ".\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			WebDriverWait wait = new WebDriverWait(driver, 10);
	        JavascriptExecutor js = (JavascriptExecutor) driver;
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get("https://www.n11.com");
			//oturum a� ekran�na git
			driver.findElement(By.xpath("/html/body/div[2]/header/div/div/div[2]/div[2]/div[2]/div/div/a[1]")).click();
			
			//alanlar� doldur
			driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/div/div[1]/div/form/div[1]/input"))
					.sendKeys(username);
			driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/div/div[1]/div/form/div[2]/input"))
					.sendKeys(password);
			driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/div/div[1]/div/form/div[4]")).click();

			//do�ru yerde miyiz kontrol et 
			String current=driver.getCurrentUrl();
			if(!current.equals("https://www.n11.com/")) {
				System.out.println(current);
				throw new Exception("Site beklenilen site de�il");
			}
			
			//arama kutusuna bilgisayar yaz
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/header/div/div/div[2]/div[1]/div/form/input[1]"))).sendKeys("bilgisayar");;

			
			driver.findElement(By.xpath("/html/body/div[2]/header/div/div/div[2]/div[1]/a")).click();
			js.executeScript("window.scrollBy(0,1000)");
			
			//2. sayfaya git
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[4]/a[2]")).click();
			
			//2. sayfada m�y�z kontrol et
			if(!driver.getCurrentUrl().equals("https://www.n11.com/arama?q=bilgisayar&pg=2")) {
				System.out.println(current);
				throw new Exception("Site beklenilen site de�il");
			}
			
			//rasgele bir �r�n se�
			WebElement elem = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/section[1]/div[2]/ul/li["+random+"]/div/div[1]/a"));
			js.executeScript("arguments[0].click();", elem);
			File fiyat=new File(".\\fiayt.txt");
			FileWriter wr=new FileWriter(fiyat);
			
			//bilgilerini dosyaya yaz
			String ad = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[3]/div[2]/div[1]/div/h1")).getText();
			wr.write(ad+"\r\n");
			
			String price = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[3]/div[2]/div[3]/div[2]/div/div[1]/div/ins")).getText();
			wr.write(price+"\r\n");
			wr.close();
			
			//sepete ekle
			elem = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[3]/div[2]/div[3]/div[3]/a[2]"));
			js.executeScript("arguments[0].click();", elem);
			
			//sepete git
			elem = driver.findElement(By.xpath("/html/body/div[1]/header/div/div/div[2]/div[2]/div[4]/a"));
			js.executeScript("arguments[0].click();", elem);

			String basketPrice = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div[3]/div/div/section/div[5]/span[2]")).getText();

			if(!basketPrice.equals(price)) {
				throw new Exception("sepetteki fiyat �r�n fiyat�ndan farkl�");
			}
			
			//�r�n� artt�r
			elem = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div[2]/div[1]/section/table[2]/tbody/tr/td[3]/div[1]/div/span[1]"));
			js.executeScript("arguments[0].click();", elem);

			String quantity = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div[2]/div[1]/section/table[2]/tbody/tr/td[3]/div[1]/input")).getAttribute("value");
			
			//artt�r�lm�� m� kontrol et
			if(!"2".equals(quantity)) {
				throw new Exception("�r�n artt�rma hatas�");
			}
			else {
				System.out.println("devam ediyoruz");
			}
			
			//�r�n� sil
			elem = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div[2]/div[1]/section/table[2]/tbody/tr/td[1]/div[3]/div[2]/span[1]"));
			js.executeScript("arguments[0].click();", elem);
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			try {
				elem = driver.findElement(By.ByClassName.className("cartEmptyText"));				
			} catch (NoSuchElementException e) {
				throw new Exception("�r�n kald�rma hatas�");
			}
			
			System.out.println("senaryo s�ras�nda sorun olmad�");
			
			driver.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
